Data collected around 2017-12-17 by OpenAddresses (http://openaddresses.io).

Address data is essential infrastructure. Street names, house numbers and
postal codes, when combined with geographic coordinates, are the hub that
connects digital to physical places.

Data licenses can be found in LICENSE.txt.

Data source information can be found at
https://github.com/openaddresses/openaddresses/tree/08475cf122dc6129538ad528f6ca65eb3645ce89/sources
